package com.itheima.pinda.mapper;

import com.itheima.pinda.mapper.base.BaseMapper;
import org.springframework.stereotype.Component;

@Component
public class MessageMapper extends BaseMapper {

}
