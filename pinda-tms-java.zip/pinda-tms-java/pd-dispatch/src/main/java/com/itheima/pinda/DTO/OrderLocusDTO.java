package com.itheima.pinda.DTO;

import lombok.Data;

@Data
public class OrderLocusDTO {
    private String businessId;
    private String beginTime;
    private String endTime;
}
