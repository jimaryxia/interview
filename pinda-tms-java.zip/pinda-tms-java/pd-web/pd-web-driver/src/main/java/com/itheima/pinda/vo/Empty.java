package com.itheima.pinda.vo;

public class Empty {
}
