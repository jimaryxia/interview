package com.itheima.pinda.service;

import com.itheima.pinda.entity.Member;

public interface IMemberService {
    Member detail(String userId);
}
