package com.itheima.pinda.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.itheima.pinda.entity.Member;

/**
 * 用户服务接口
 */
public interface IMemberService extends IService<Member> {

}