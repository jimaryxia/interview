package com.itheima.pinda.service;
import com.baomidou.mybatisplus.extension.service.IService;
import com.itheima.pinda.entity.AddressBook;

/**
 * 地址簿
 */
public interface IAddressBookService extends IService<AddressBook> {

}
