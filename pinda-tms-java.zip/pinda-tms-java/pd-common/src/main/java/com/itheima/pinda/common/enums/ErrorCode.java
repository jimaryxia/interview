package com.itheima.pinda.common.enums;

public class ErrorCode {
    public static Integer ONTHEWAY = 400;
}
